
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.emeraldaddons.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.emeraldaddons.item.EmeraldSwordItem;
import net.mcreator.emeraldaddons.item.EmeraldShovelItem;
import net.mcreator.emeraldaddons.item.EmeraldPickaxeItem;
import net.mcreator.emeraldaddons.item.EmeraldHoeItem;
import net.mcreator.emeraldaddons.item.EmeraldAxeItem;
import net.mcreator.emeraldaddons.EmeraldaddonsMod;

public class EmeraldaddonsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, EmeraldaddonsMod.MODID);
	public static final RegistryObject<Item> EMERALD_PICKAXE = REGISTRY.register("emerald_pickaxe", () -> new EmeraldPickaxeItem());
	public static final RegistryObject<Item> EMERALD_AXE = REGISTRY.register("emerald_axe", () -> new EmeraldAxeItem());
	public static final RegistryObject<Item> EMERALD_SHOVEL = REGISTRY.register("emerald_shovel", () -> new EmeraldShovelItem());
	public static final RegistryObject<Item> EMERALD_HOE = REGISTRY.register("emerald_hoe", () -> new EmeraldHoeItem());
	public static final RegistryObject<Item> EMERALD_SWORD = REGISTRY.register("emerald_sword", () -> new EmeraldSwordItem());
}
